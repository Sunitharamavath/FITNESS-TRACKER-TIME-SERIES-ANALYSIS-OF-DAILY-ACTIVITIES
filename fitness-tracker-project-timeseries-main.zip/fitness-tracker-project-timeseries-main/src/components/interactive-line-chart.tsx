"use client";

import { FitnessData } from "@/app/dashboard/page";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";

type Props = {
  data: FitnessData[];
};

export function InteractiveLineChart({ data }: Props) {
  const lineData = data.map(item => ({
    date: item.date,
    waterIntake: item.waterIntake,
  }));

  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={lineData}
        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="date" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="waterIntake" stroke="hsl(var(--chart-2))" activeDot={{ r: 8 }} />
      </LineChart>
    </ResponsiveContainer>
  );
}
