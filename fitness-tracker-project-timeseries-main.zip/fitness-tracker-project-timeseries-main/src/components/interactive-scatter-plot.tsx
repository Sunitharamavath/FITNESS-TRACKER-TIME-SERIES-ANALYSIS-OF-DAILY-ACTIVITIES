"use client";

import { FitnessData } from "@/app/dashboard/page";
import {
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from "recharts";

type Props = {
  data: FitnessData[];
};

const calculateCalories = (workoutType: string, weight: number, workoutTime: number): number => {
  const metValues: { [key: string]: number } = {
    running: 9.8,
    walking: 3.8,
    cycling: 7.5,
    swimming: 8.0,
    strength_training: 6.0,
    default: 5.0,
  };

  const met = metValues[workoutType] || metValues.default;
  return (met * weight * 3.5 / 200) * workoutTime;
};

export function InteractiveScatterPlot({ data }: Props) {
  const scatterData = data.map(item => ({
    date: item.date,
    workoutTime: item.workoutTime,
    calories: calculateCalories(item.workoutType, item.weight, item.workoutTime),
  }));

  return (
    <ResponsiveContainer width="100%" height={300}>
      <ScatterChart
        margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="workoutTime" name="Workout Time (minutes)" unit="min" />
        <YAxis dataKey="calories" name="Calories Burned" unit="kcal" />
        <Tooltip />
        <Scatter name="Calories vs Workout Time" data={scatterData} fill="hsl(var(--chart-3))" />
      </ScatterChart>
    </ResponsiveContainer>
  );
}
