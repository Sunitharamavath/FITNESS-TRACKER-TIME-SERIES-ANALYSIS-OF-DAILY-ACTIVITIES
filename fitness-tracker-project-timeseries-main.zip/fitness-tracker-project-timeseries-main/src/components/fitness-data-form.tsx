"use client";

import {Calendar} from "@/components/ui/calendar";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {Input} from "@/components/ui/input";
import {Button} from "@/components/ui/button";
import {cn} from "@/lib/utils";
import {Popover, PopoverContent, PopoverTrigger} from "@/components/ui/popover";
import {Select, SelectContent, SelectItem, SelectTrigger, SelectValue} from "@/components/ui/select";
import {Textarea} from "@/components/ui/textarea";
import {useForm} from "react-hook-form";
import {CalendarIcon} from "lucide-react";
import {format} from "date-fns";
import {useToast} from "@/hooks/use-toast";
import {z} from "zod";
import {zodResolver} from "@hookform/resolvers/zod";
import {useState} from "react";

type FormData = {
  date: Date;
  steps: number;
  workoutTime: number;
  workoutType: string;
  weight: number;
  waterIntake: number;
};

const formSchema = z.object({
  date: z.date({
    required_error: "A date is required.",
  }),
  steps: z.coerce.number().min(0, {
    message: "Please enter valid steps count.",
  }),
  workoutTime: z.coerce.number().min(0, {
    message: "Please enter valid workout time.",
  }),
  workoutType: z.string().min(1, {
    message: "Please select a workout type.",
  }),
  weight: z.coerce.number().min(0, {
    message: "Please enter valid weight.",
  }),
  waterIntake: z.coerce.number().min(0, {
    message: "Please enter valid water intake.",
  }),
});

type Props = {
  onSubmit: (data: Omit<FormData, 'date'> & { date: string }) => void;
};

export function FitnessDataForm({onSubmit}: Props) {
  const [open, setOpen] = useState(false);
  const {toast} = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      date: undefined,
      steps: 0,
      workoutTime: 0,
      workoutType: "",
      weight: 0,
      waterIntake: 0,
    },
  });

  const onSubmitHandler = (values: z.infer<typeof formSchema>) => {
    // Do something with the form values.
    // ✅ This will be type-safe and validated.
    console.log(values);
    onSubmit({
      ...values,
      date: format(values.date, "yyyy-MM-dd"),
    });
    toast({
      title: "Success!",
      description: "Your data have been submited.",
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmitHandler)} className="space-y-6">
        <FormField
          control={form.control}
          name="date"
          render={({field}) => (
            <FormItem className="flex flex-col">
              <FormLabel>Date</FormLabel>
              <Popover open={open} onOpenChange={setOpen}>
                <PopoverTrigger asChild>
                  <FormControl>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-[240px] pl-3 text-left font-normal",
                        !field.value && "text-muted-foreground"
                      )}
                    >
                      {field.value ? (
                        format(field.value, "yyyy-MM-dd")
                      ) : (
                        <span>Pick a date</span>
                      )}
                      <CalendarIcon className="ml-auto h-4 w-4 opacity-50"/>
                    </Button>
                  </FormControl>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start" side="bottom">
                  <Calendar
                    mode="single"
                    selected={field.value}
                    onSelect={field.onChange}
                    disabled={(date) =>
                      date > new Date() || date < new Date("1900-01-01")
                    }
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
              <FormDescription>
                The date for which you are entering fitness data.
              </FormDescription>
              <FormMessage/>
            </FormItem>
          )}
        />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="steps"
            render={({field}) => (
              <FormItem>
                <FormLabel>Steps</FormLabel>
                <FormControl>
                  <Input placeholder="Enter steps" type="number" {...field} />
                </FormControl>
                <FormDescription>Number of steps taken today.</FormDescription>
                <FormMessage/>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="workoutTime"
            render={({field}) => (
              <FormItem>
                <FormLabel>Workout Time (minutes)</FormLabel>
                <FormControl>
                  <Input placeholder="Workout time in minutes" type="number" {...field} />
                </FormControl>
                <FormDescription>Duration of today's workout in minutes.</FormDescription>
                <FormMessage/>
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="workoutType"
          render={({field}) => (
            <FormItem>
              <FormLabel>Workout Type</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a workout type"/>
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="running">Running</SelectItem>
                  <SelectItem value="walking">Walking</SelectItem>
                  <SelectItem value="cycling">Cycling</SelectItem>
                  <SelectItem value="swimming">Swimming</SelectItem>
                  <SelectItem value="strength_training">Strength Training</SelectItem>
                </SelectContent>
              </Select>
              <FormDescription>Type of workout performed today.</FormDescription>
              <FormMessage/>
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="weight"
            render={({field}) => (
              <FormItem>
                <FormLabel>Weight (kg)</FormLabel>
                <FormControl>
                  <Input placeholder="Weight in kilograms" type="number" {...field} />
                </FormControl>
                <FormDescription>Your weight in kilograms.</FormDescription>
                <FormMessage/>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="waterIntake"
            render={({field}) => (
              <FormItem>
                <FormLabel>Water Intake (liters)</FormLabel>
                <FormControl>
                  <Input placeholder="Water intake in liters" type="number" {...field} />
                </FormControl>
                <FormDescription>Amount of water consumed in liters.</FormDescription>
                <FormMessage/>
              </FormItem>
            )}
          />
        </div>

        <Button type="submit">Submit</Button>
      </form>
    </Form>
  );
}
