"use client";

import Link from "next/link";
import { usePathname } from 'next/navigation'

export function Navigation() {
  const pathname = usePathname()

  return (
    <div className="flex justify-between items-center mb-4">
      <h1 className="text-2xl font-bold">Fitness Tracker</h1>
      <nav className="flex gap-4">
        <Link href="/dashboard" className={pathname === '/dashboard' ? 'font-semibold text-blue-500' : ''}>Dashboard</Link>
        <Link href="/history" className={pathname === '/history' ? 'font-semibold text-blue-500' : ''}>History</Link>
      </nav>
    </div>
  );
}
