"use client";

import { FitnessData } from "@/app/dashboard/page";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";

type Props = {
  data: FitnessData[];
};

export function InteractiveStepCountChart({ data }: Props) {
  const stepData = data.map(item => ({
    date: item.date,
    steps: item.steps,
  }));

  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={stepData}
        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="date" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar dataKey="steps" fill="hsl(var(--accent))" />
      </BarChart>
    </ResponsiveContainer>
  );
}
