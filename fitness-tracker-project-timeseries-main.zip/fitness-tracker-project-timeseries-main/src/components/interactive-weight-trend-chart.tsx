"use client";

import { FitnessData } from "@/app/dashboard/page";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

type Props = {
  data: FitnessData[];
};

export function InteractiveWeightTrendChart({ data }: Props) {
  const weightData = data.map(item => ({
    date: item.date,
    weight: item.weight,
  }));

  return (
    <ResponsiveContainer width="100%" height={300}>
      <AreaChart data={weightData}
        margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id="colorWeight" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8} />
            <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="date" />
        <YAxis />
        <Tooltip />
        <Area type="monotone" dataKey="weight" stroke="hsl(var(--primary))" fill="url(#colorWeight)" />
      </AreaChart>
    </ResponsiveContainer>
  );
}
