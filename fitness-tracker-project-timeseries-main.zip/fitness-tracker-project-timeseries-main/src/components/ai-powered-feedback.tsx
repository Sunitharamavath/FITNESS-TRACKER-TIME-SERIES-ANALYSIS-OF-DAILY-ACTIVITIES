"use client";

import {generateFitnessFeedback} from "@/ai/flows/generate-fitness-feedback";
import {FitnessData} from "@/app/page";
import {useEffect, useState} from "react";
import {Button} from "@/components/ui/button";
import {Loader2} from "lucide-react";
import {Card, CardDescription} from "@/components/ui/card";

type Props = {
  fitnessData: FitnessData[];
};

export function AIPoweredFeedback({fitnessData}: Props) {
  const [feedback, setFeedback] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      if (fitnessData.length > 0) {
        setIsLoading(true);
        const latestData = fitnessData[fitnessData.length - 1];
        try {
          const result = await generateFitnessFeedback({
            date: latestData.date,
            steps: latestData.steps,
            workoutTime: latestData.workoutTime,
            workoutType: latestData.workoutType,
            weight: latestData.weight,
            waterIntake: latestData.waterIntake,
            weeklyStepsChange: latestData.weeklyStepsChange,
            weeklyWeightChange: latestData.weeklyWeightChange,
            waterIntakeConsistency: latestData.waterIntakeConsistency,
          });
          setFeedback(result.feedback);
        } catch (error) {
          console.error("Error fetching feedback:", error);
          setFeedback("Failed to generate feedback. Please try again.");
        } finally {
          setIsLoading(false);
        }
      } else {
        setFeedback("No data available to generate feedback.");
      }
    };

    fetchData();
  }, [fitnessData]);

  return (
    <div>
      {isLoading ? (
        <div className="flex items-center justify-center">
          <Loader2 className="mr-2 h-4 w-4 animate-spin"/>
          Generating feedback...
        </div>
      ) : (
        <>
          {feedback ? (
            <CardDescription className="text-sm">{feedback}</CardDescription>
          ) : (
            <CardDescription className="text-sm">No feedback available.</CardDescription>
          )}
        </>
      )}
    </div>
  );
}
