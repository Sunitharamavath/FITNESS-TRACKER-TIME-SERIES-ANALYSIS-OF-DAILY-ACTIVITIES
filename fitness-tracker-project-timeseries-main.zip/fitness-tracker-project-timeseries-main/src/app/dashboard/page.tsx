"use client";

import { FitnessDataForm } from '@/components/fitness-data-form';
import { InteractiveWeightTrendChart } from '@/components/interactive-weight-trend-chart';
import { InteractiveStepCountChart } from '@/components/interactive-step-count-chart';
import { AIPoweredFeedback } from '@/components/ai-powered-feedback';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Navigation } from '@/components/navigation';
import { useEffect, useState } from 'react';
import { InteractiveScatterPlot } from '@/components/interactive-scatter-plot';
import { InteractiveLineChart } from '@/components/interactive-line-chart';

export type FitnessData = {
  date: string;
  steps: number;
  workoutTime: number;
  workoutType: string;
  weight: number;
  waterIntake: number;
  weeklyStepsChange: number;
  weeklyWeightChange: number;
  waterIntakeConsistency: number;
};

const initialFitnessData: FitnessData[] = [];

export default function Dashboard() {
  const [fitnessData, setFitnessData] = useState<FitnessData[]>(initialFitnessData);

  const addFitnessData = (newFitnessData: Omit<FitnessData, 'weeklyStepsChange' | 'weeklyWeightChange' | 'waterIntakeConsistency'>) => {
    // Calculate weekly changes and consistency (Placeholder logic, needs actual calculation)
    const weeklyStepsChange = newFitnessData.steps - (fitnessData.length > 0 ? fitnessData[fitnessData.length - 1].steps : 0);
    const weeklyWeightChange = newFitnessData.weight - (fitnessData.length > 0 ? fitnessData[fitnessData.length - 1].weight : 0);
    const waterIntakeConsistency = 0.7; // Example value

    const data: FitnessData = {
      ...newFitnessData,
      weeklyStepsChange,
      weeklyWeightChange,
      waterIntakeConsistency,
    };
    setFitnessData([...fitnessData, data]);
  };

  return (
    <div className="container mx-auto p-4">
      <Navigation />

      <Card className="mb-4">
        <CardHeader>
          <CardTitle>Daily Fitness Data Input</CardTitle>
          <CardDescription>Enter your fitness metrics for today.</CardDescription>
        </CardHeader>
        <CardContent>
          <FitnessDataForm onSubmit={addFitnessData} />
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <Card>
          <CardHeader>
            <CardTitle>Weight Trend</CardTitle>
            <CardDescription>Your weight progression over time.</CardDescription>
          </CardHeader>
          <CardContent>
            <InteractiveWeightTrendChart data={fitnessData} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Step Count Trend</CardTitle>
            <CardDescription>Your daily step count over time.</CardDescription>
          </CardHeader>
          <CardContent>
            <InteractiveStepCountChart data={fitnessData} />
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <Card>
          <CardHeader>
            <CardTitle>Calories vs Workout Time</CardTitle>
            <CardDescription>See the relation between calories burned and workout time.</CardDescription>
          </CardHeader>
          <CardContent>
            <InteractiveScatterPlot data={fitnessData} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Water Intake Over Time</CardTitle>
            <CardDescription>Track your water intake consistency.</CardDescription>
          </CardHeader>
          <CardContent>
            <InteractiveLineChart data={fitnessData} />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Personalized AI Feedback</CardTitle>
          <CardDescription>AI-generated insights and motivation based on your data.</CardDescription>
        </CardHeader>
        <CardContent>
          <AIPoweredFeedback fitnessData={fitnessData} />
        </CardContent>
      </Card>
    </div>
  );
}
