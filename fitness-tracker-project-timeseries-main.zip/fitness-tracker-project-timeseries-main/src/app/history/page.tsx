"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Navigation } from "@/components/navigation";
import { FitnessData } from "@/app/dashboard/page";
import { useEffect, useState } from "react";

const initialFitnessData: FitnessData[] = [];

export default function History() {
  const [fitnessData, setFitnessData] = useState<FitnessData[]>(initialFitnessData);

  return (
    <div className="container mx-auto p-4">
      <Navigation />
      <Card>
        <CardHeader>
          <CardTitle>Fitness Data History</CardTitle>
        </CardHeader>
        <CardContent>
          {fitnessData.length > 0 ? (
            <table className="table-auto w-full">
              <thead>
                <tr>
                  <th className="px-4 py-2">Date</th>
                  <th className="px-4 py-2">Steps</th>
                  <th className="px-4 py-2">Weight (kg)</th>
                  <th className="px-4 py-2">Workout Type</th>
                  <th className="px-4 py-2">Workout Time (min)</th>
                  <th className="px-4 py-2">Water Intake (L)</th>
                </tr>
              </thead>
              <tbody>
                {fitnessData.map((data, index) => (
                  <tr key={index}>
                    <td className="border px-4 py-2">{data.date}</td>
                    <td className="border px-4 py-2">{data.steps}</td>
                    <td className="border px-4 py-2">{data.weight}</td>
                    <td className="border px-4 py-2">{data.workoutType}</td>
                    <td className="border px-4 py-2">{data.workoutTime}</td>
                    <td className="border px-4 py-2">{data.waterIntake}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p>No fitness data available.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
