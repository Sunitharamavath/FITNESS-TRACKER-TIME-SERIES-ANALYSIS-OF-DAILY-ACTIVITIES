# **App Name**: FitnessFlow

## Core Features:

- Data Input Form: Interactive form for users to input daily fitness data (date, steps, workout time, workout type, weight, water intake).
- Weight Trend Visualization: Display weight over time using a line chart.
- Step Count Visualization: Display steps over time using a bar chart.
- AI-Powered Feedback: Generate personalized feedback based on user's fitness data trends and progress using an AI tool. This includes suggestions for improvement and motivational messages.

## Style Guidelines:

- Primary color: Teal (#008080) to represent health and vitality.
- Accent: Coral (#FF7F50) for interactive elements and call-to-action buttons.
- Clean and modern layout with a focus on data visualization.
- Simple and consistent icons to represent different fitness metrics.
- Subtle transitions and animations to enhance user experience when data is updated.

## Original User Request:
Create a full-stack fitness tracker website using Flask (Python backend) and HTML/JavaScript (frontend) with the following requirements:

📁 Folder Structure:
- backend/
  - app.py (Flask server)
  - fitness_data.csv (auto-created on first run)
  - requirements.txt
  - Procfile
- templates/
  - index.html (user form + visualizations + feedback)
- static/
  - script.js (AJAX + D3.js visualizations)
  - style.css (optional)

✅ Core Functionalities:

1. **Frontend (index.html)**:
   - Form to collect:
     - Date (YYYY-MM-DD)
     - Steps
     - Workout time (minutes)
     - Workout type (dropdown: running, walking, cycling, swimming, strength_training)
     - Weight (kg)
     - Water intake (liters)
   - Submit button → sends data via `fetch` POST to `/add-data`
   - D3.js **time series visualizations**:
     - Line chart: **Weight over time**
     - Bar chart: **Steps over time**
     - Optional: Scatter plot of **Calories vs Workout Time**
   - **Section for feedback/insights** fetched from `/feedback`

2. **Backend (Flask app.py)**:
   - `/add-data` (POST):
     - Saves data to `fitness_data.csv`
     - Calculates calories using MET formula:
       ```
       MET values:
       - running: 9.8
       - walking: 3.8
       - cycling: 7.5
       - swimming: 8.0
       - strength_training: 6.0
       - default: 5.0

       Calories = (MET * weight * 3.5 / 200) * workout_time
       ```
   - `/get-data` (GET): Returns all records as JSON
   - `/heatmap` (GET): Returns a heatmap image (steps vs day of week)
   - `/feedback` (GET): Returns a JSON message with **simple insights**, like:
     - "Great job! You've been consistent with steps this week."
     - "Try increasing your water intake to at least 2L/day."
     - "You've lost 1.5 kg in the last 2 weeks — keep it up!"

3. **Time Series Focus**:
   - All charts should emphasize trends over time
   - Data updates dynamically when user submits new entry

4. **Insightful Feedback Engine**:
   - Use Python logic in `/feedback` to analyze trends like:
     - Weekly step improvement or drop
     - Recent weight gain/loss
     - Consistency in workouts or water intake

5. **Deployment Ready**:
   - `requirements.txt`:
     ```
     flask
     pandas
     matplotlib
     seaborn
     gunicorn
     ```
   - `Procfile`:
     ```
     web: gunicorn app:app
     ```

🎯 Goal: A clean, interactive website that helps users **track fitness metrics over time**, **visualize progress**, and **receive motivational feedback** — ready to deploy on Render.
  